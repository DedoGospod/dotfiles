local packages = {
    "hyprland", "hypridle", "hyprlock", "hyprpaper", "hyprshot", "hyprpolkitagent", "hyprland-guiutils",
    "hyprutils", "uwsm", "waybar", "wofi", "swaync", "dbus", "hyprsunset", "pyprland", "xdg-desktop-portal-hyprland",
    "xdg-desktop-portal", "xdg-desktop-portal-gtk"
}

return {
    description = "Hyprland specific packages",
    packages = packages,
}
