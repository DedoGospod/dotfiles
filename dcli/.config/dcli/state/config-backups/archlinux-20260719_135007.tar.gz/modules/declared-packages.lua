return {
    description = "Packages installed via dcli install or dcli search commands",
    packages = {
    },
}
