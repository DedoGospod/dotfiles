local packages = {
    -- Theme
    "qt5-wayland", "qt6-wayland", "qt6ct", "gnome-themes-extra",
    -- Fonts
    "ttf-cascadia-code-nerd", "ttf-ubuntu-font-family", "ttf-font-awesome",
    "ttf-dejavu", "ttf-liberation", "ttf-croscore", "noto-fonts", "noto-fonts-cjk",
    "noto-fonts-emoji"
}

return {
    description = "Packages needed for configuring the theme",
    packages = packages,
}
